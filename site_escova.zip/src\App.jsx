import React, { useState } from 'react';
import heroImg from './assets/straightener_hero_1782682952932.png';
import bristlesImg from './assets/straightener_bristles_1782682961267.png';
import modelImg from './assets/woman_straight_hair_1782682970346.png';

function App() {
  const [activeFaq, setActiveFaq] = useState(null);

  const toggleFaq = (index) => {
    if (activeFaq === index) {
      setActiveFaq(null);
    } else {
      setActiveFaq(index);
    }
  };

  const faqs = [
    { question: "A escova funciona em cabelos grossos e cacheados?", answer: "Sim! Ela foi projetada para alisar até os cabelos mais difíceis graças aos seus 5 níveis de temperatura." },
    { question: "A escova pode danificar o cabelo?", answer: "Não, a tecnologia de íons protege os fios enquanto alisa, reduzindo o frizz sem causar danos térmicos extremos." },
    { question: "Ela substitui chapinha e secador?", answer: "Para a grande maioria das nossas clientes, sim. A UltraLiss Pro® oferece um alisamento rápido e natural que substitui a chapinha no dia a dia." },
    { question: "Funciona em qualquer tomada?", answer: "Sim! A UltraLiss Pro® é bivolt automática (110V-220V)." },
    { question: "Quanto tempo demora para alisar o cabelo?", answer: "Muitas clientes relatam economizar até 40 minutos, conseguindo um cabelo alinhado em poucos minutos." },
    { question: "É fácil de usar?", answer: "Muito fácil! Basta conectar, escolher a temperatura, aguardar alguns segundos e escovar o cabelo normalmente." },
    { question: "Como vou receber o Ebook Bônus?", answer: "Ele será enviado automaticamente para o seu e-mail logo após a confirmação da compra." }
  ];

  return (
    <div>
      {/* Top Banner Marquee */}
      <div className="top-banner">
        <div className="marquee-content">
          <span className="marquee-item">🔥 OFERTA ESPECIAL POR TEMPO LIMITADO</span>
          <span className="marquee-item">🚚 FRETE GRÁTIS PARA TODO O BRASIL</span>
          <span className="marquee-item">⚠️ ÚLTIMAS UNIDADES DISPONÍVEIS</span>
          <span className="marquee-item">🔥 OFERTA ESPECIAL POR TEMPO LIMITADO</span>
          <span className="marquee-item">🚚 FRETE GRÁTIS PARA TODO O BRASIL</span>
          <span className="marquee-item">⚠️ ÚLTIMAS UNIDADES DISPONÍVEIS</span>
        </div>
      </div>

      {/* Hero Section */}
      <section className="hero">
        <div className="container hero-grid">
          <div className="product-gallery">
            <img src={heroImg} alt="UltraLiss Pro®" />
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <img src={heroImg} alt="Thumbnail 1" style={{ width: '23%', borderRadius: 'var(--radius-sm)' }} />
              <img src={bristlesImg} alt="Thumbnail 2" style={{ width: '23%', borderRadius: 'var(--radius-sm)' }} />
              <img src={modelImg} alt="Thumbnail 3" style={{ width: '23%', borderRadius: 'var(--radius-sm)' }} />
              <img src={heroImg} alt="Thumbnail 4" style={{ width: '23%', borderRadius: 'var(--radius-sm)' }} />
            </div>
          </div>
          
          <div>
            <div className="reviews-badge">
              ⭐⭐⭐⭐⭐ 4,9/5 (+2.354 avaliações verificadas)
            </div>
            <h1 style={{ marginBottom: '0.5rem' }}>UltraLiss Pro® <br/><span style={{fontSize:'1.5rem', fontWeight:'400', color:'var(--text-light)'}}>- Escova Alisadora Portátil - 🇧🇷 Brasil</span></h1>
            
            <p style={{ fontWeight: '600', color: 'var(--secondary)', fontSize: '1.2rem', marginTop: '1rem' }}>
              🔥 Conquiste cabelos mais alinhados, brilhantes e com menos frizz em poucos minutos.
            </p>
            <p>
              Chega de perder tempo com aparelhos complicados, gastar dinheiro frequentemente em salão ou enfrentar todos os dias cabelos difíceis de modelar.
            </p>
            <p>
              A UltraLiss Pro® foi desenvolvida para ajudar você a alisar, alinhar e modelar os fios com praticidade, proporcionando um visual bonito e bem cuidado no conforto da sua casa.
            </p>

            <div className="price-block">
              <span style={{background: 'var(--primary)', color:'white', padding:'4px 8px', borderRadius:'4px', fontWeight:'bold', fontSize:'0.9rem', marginBottom:'0.5rem', display:'inline-block'}}>36% OFF</span>
              <div className="old-price">De R$ 139,90</div>
              <div className="new-price">R$ 89,90</div>
              <p className="text-success font-bold" style={{marginBottom: 0}}>✅ FRETE GRÁTIS PARA TODO O BRASIL</p>
            </div>

            <a href="#comprar" className="btn btn-primary" style={{ display: 'flex', width: '100%', maxWidth: 'none' }}>COMPRAR AGORA COM DESCONTO</a>
            <p className="text-center" style={{ fontSize: '0.9rem', marginTop: '0.5rem' }}>Aprovada por milhares: de Babi e Sueli a mais de 10 mil clientes.</p>

            <ul className="check-list">
              <li>Praticidade e rapidez no uso</li>
              <li>Resultado de salão em casa</li>
              <li>Cabelos lisos onde você estiver</li>
              <li>5 níveis de temperatura ajustáveis</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Sub-hero features */}
      <section className="section bg-gray">
        <div className="container text-center">
          <h2>Imagine ter cabelos impecáveis em qualquer hora e lugar!</h2>
          <p style={{ maxWidth: '800px', margin: '0 auto 2rem' }}>
            Descubra a máxima conveniência no cuidado dos cabelos com a Escova UltraLiss Pro® com fio. Perfeita para alisamento prático e confortável, seu design ergonômico oferece resultados de salão em casa com tecnologia bivolt automática.
          </p>
          <div className="steps-grid" style={{ marginBottom: '3rem' }}>
            <div className="step-card">
              <h3 className="text-primary" style={{marginBottom:'1rem'}}>🌡️</h3>
              <h4 style={{marginBottom:'0.5rem'}}>5 níveis de temperatura inteligentes</h4>
            </div>
            <div className="step-card">
              <h3 className="text-primary" style={{marginBottom:'1rem'}}>✨</h3>
              <h4 style={{marginBottom:'0.5rem'}}>Tecnologia antifrizz para fios mais alinhados</h4>
            </div>
            <div className="step-card">
              <h3 className="text-primary" style={{marginBottom:'1rem'}}>💇‍♀️</h3>
              <h4 style={{marginBottom:'0.5rem'}}>Resultado de salão sem sair de casa</h4>
            </div>
            <div className="step-card">
              <h3 className="text-primary" style={{marginBottom:'1rem'}}>⚡</h3>
              <h4 style={{marginBottom:'0.5rem'}}>Bivolt automático + design ergonômico</h4>
            </div>
          </div>
          <a href="#comprar" className="btn btn-primary">✨ GARANTIR MINHA ULTRALISS PRO ✨</a>
        </div>
      </section>

      {/* Action / Results */}
      <section className="section">
        <div className="container text-center">
          <h2 className="text-primary">✨ Veja a UltraLiss Pro® em ação</h2>
          <p style={{ maxWidth: '600px', margin: '0 auto 3rem' }}>
            Milhares de mulheres já estão conquistando cabelos mais alinhados, modelados e com menos frizz no conforto de casa.
          </p>
          <div className="product-gallery" style={{ maxWidth: '800px', margin: '0 auto' }}>
            <img src={modelImg} alt="Mulher usando UltraLiss Pro" />
          </div>
        </div>
      </section>

      {/* Como Funciona */}
      <section className="section bg-primary-light">
        <div className="container">
          <div className="text-center">
            <h2>✨ COMO FUNCIONA</h2>
            <p style={{ maxWidth: '600px', margin: '0 auto 2rem' }}>
              Em poucos minutos você pode conquistar cabelos mais alinhados, modelados e com menos frizz.
            </p>
          </div>
          <div className="steps-grid">
            <div className="step-card">
              <div className="step-number">1</div>
              <h3>Ligue sua UltraLiss Pro®</h3>
              <p>Conecte a escova e selecione a temperatura ideal para o seu tipo de cabelo.</p>
            </div>
            <div className="step-card">
              <div className="step-number">2</div>
              <h3>Aguarde o aquecimento</h3>
              <p>Em poucos segundos ela estará pronta para uso.</p>
            </div>
            <div className="step-card">
              <div className="step-number">3</div>
              <h3>Deslize pelos fios</h3>
              <p>Passe a escova da raiz às pontas para alinhar, modelar e reduzir o frizz.</p>
            </div>
            <div className="step-card">
              <div className="step-number">4</div>
              <h3>Aproveite o resultado</h3>
              <p>Tenha cabelos com aparência mais bonita, alinhada e bem cuidada sem precisar sair de casa.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Comparison */}
      <section className="section">
        <div className="container">
          <div className="text-center">
            <h2>Por que a UltraLiss Pro® é diferente</h2>
            <p>Com a UltraLiss Pro, temos certeza que você vai amar o resultado. É por isso que oferecemos uma garantia de satisfação de 7 dias após chegar em sua casa.</p>
          </div>
          <table className="comparison-table">
            <thead>
              <tr>
                <th>Benefícios</th>
                <th>UltraLiss Pro®</th>
                <th>Outras Marcas</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Cabelo pronto em poucos minutos</td>
                <td>✔️</td>
                <td>❌</td>
              </tr>
              <tr>
                <td>Tecnologia de íons que protege os fios</td>
                <td>✔️</td>
                <td>❌</td>
              </tr>
              <tr>
                <td>5 Níveis de Temperatura</td>
                <td>✔️</td>
                <td>❌</td>
              </tr>
              <tr>
                <td>Recomendada por profissionais</td>
                <td>✔️</td>
                <td>❌</td>
              </tr>
              <tr>
                <td>Custam muito caro</td>
                <td>❌</td>
                <td>✔️</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section bg-gray">
        <div className="container">
          <div className="text-center">
            <h2>Mais de 10.000+ clientes satisfeitas</h2>
            <p>Os resultados que falam por si só.</p>
          </div>
          <div className="testimonials-grid">
            <div className="testimonial-card">
              <div className="stars">⭐⭐⭐⭐⭐</div>
              <h3 style={{marginBottom:'0.5rem'}}>Meu novo xodó</h3>
              <p>"Uso a UltraLiss Pro há mais de dois meses e continua funcionando como no primeiro dia. Economizei muito em salão e meu cabelo está mais saudável e com brilho."</p>
            </div>
            <div className="testimonial-card">
              <div className="stars">⭐⭐⭐⭐⭐</div>
              <h3 style={{marginBottom:'0.5rem'}}>Prática no dia a dia</h3>
              <p>"Uso antes de sair para o trabalho e amei a praticidade. Meu cabelo fica muito mais alinhado em poucos minutos e sem aquela demora da chapinha. Ficou muito mais fácil me arrumar no dia a dia."</p>
            </div>
            <div className="testimonial-card">
              <div className="stars">⭐⭐⭐⭐⭐</div>
              <h3 style={{marginBottom:'0.5rem'}}>Essencial no meu dia a dia</h3>
              <p>"Simples de usar, aquece rapidinho e deixa o cabelo liso em minutos. Me sinto mais segura do que com chapinha tradicional, porque não queima os fios."</p>
            </div>
            <div className="testimonial-card">
              <div className="stars">⭐⭐⭐⭐⭐</div>
              <h3 style={{marginBottom:'0.5rem'}}>Escova dos sonhos</h3>
              <p>"Eu não acreditava que dava pra alisar em 5 minutos… mas testei e fiquei chocada! Minha rotina de quase 1 hora com secador e chapinha virou questão de minutos."</p>
            </div>
          </div>
        </div>
      </section>

      {/* Survey Results */}
      <section className="section">
        <div className="container text-center">
          <h2>Benefícios comprovados, Resultados reais</h2>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-number">98%</div>
              <p className="font-bold">disseram que não se preocupam mais com cabelo alto ou armado</p>
            </div>
            <div className="stat-card">
              <div className="stat-number">89%</div>
              <p className="font-bold">notaram que economizaram até 40 minutos na rotina de cuidados</p>
            </div>
            <div className="stat-card">
              <div className="stat-number">64%</div>
              <p className="font-bold">aposentaram a chapinha tradicional depois de testar a UltraLiss Pro®</p>
            </div>
          </div>
          <p style={{fontSize:'0.9rem'}}>*Pesquisa com clientes reais após 4 semanas de uso</p>
        </div>
      </section>

      {/* Bonus Box & Final Pricing */}
      <section className="section bg-gray" id="comprar">
        <div className="container">
          <div className="text-center">
            <h2 className="text-danger">⏰ Oferta por tempo limitado</h2>
          </div>
          
          <div className="bonus-box">
            <div>
              <h2 className="text-gold">🎁 BÔNUS EXCLUSIVO</h2>
              <p>Na compra da UltraLiss Pro hoje, você recebe gratuitamente:</p>
              <h3 style={{marginTop:'1.5rem', marginBottom:'1rem'}}>📚 Ebook Digital: "5 Penteados Rápidos para o Dia a Dia"</h3>
              <p>Um guia completo com penteados práticos e elegantes para você usar todos os dias.</p>
              <ul className="check-list" style={{ color: 'white' }}>
                <li style={{ color: 'white' }}>Penteados rápidos e práticos</li>
                <li style={{ color: 'white' }}>Para diferentes tipos de cabelo</li>
                <li style={{ color: 'white' }}>Ideal para trabalho e eventos</li>
              </ul>
            </div>
            <div className="bonus-price">
              <p style={{textDecoration:'line-through', marginBottom:'0'}}>Valor do Ebook: R$ 39,90</p>
              <h2 className="text-success" style={{fontSize:'2.5rem', margin:'0.5rem 0'}}>Hoje: GRÁTIS</h2>
              <p style={{fontStyle:'italic'}}>✓ Enviado automaticamente após a compra</p>
            </div>
          </div>

          <div style={{ maxWidth: '600px', margin: '0 auto', background: 'var(--white)', padding: '3rem', borderRadius: 'var(--radius-lg)', boxShadow: '0 20px 40px rgba(0,0,0,0.1)', textAlign: 'center', borderTop: '6px solid var(--danger)' }}>
            <h3 className="text-danger" style={{marginBottom:'1rem'}}>🔴 RESTAM POUCAS UNIDADES PROMOCIONAIS</h3>
            <div className="old-price" style={{fontSize:'1.5rem'}}>De R$ 139,90</div>
            <div className="new-price" style={{fontSize:'4rem'}}>R$ 89,90</div>
            <p className="font-bold" style={{fontSize:'1.3rem'}}>💳 ou em até 12x de R$ 14,49</p>
            
            <div style={{textAlign:'left', margin:'2rem 0', background:'#f0fff4', padding:'1.5rem', borderRadius:'var(--radius-md)'}}>
              <p className="font-bold text-success" style={{marginBottom:'0.5rem'}}>✅ Frete Grátis para todo o Brasil</p>
              <p className="font-bold text-success" style={{marginBottom:'0.5rem'}}>✅ Ebook Exclusivo Grátis "5 Penteados Rápidos"</p>
              <p className="font-black text-primary" style={{marginTop:'1rem', textAlign:'center'}}>🟢 VOCÊ ECONOMIZA R$ 50,00 NESTA OFERTA!</p>
            </div>
            
            <p className="font-bold" style={{marginBottom:'1.5rem'}}>COR: PRETO</p>
            
            <a href="#" className="btn btn-primary" style={{ width: '100%', maxWidth: 'none', padding: '1.5rem' }}>✨ QUERO MEU CABELO LISO AGORA ✨</a>
            <p style={{fontSize:'0.9rem', marginTop:'1rem'}}>
              A alta procura pela UltraLiss Pro® e pelo Ebook Exclusivo está fazendo nosso estoque promocional acabar rapidamente. Aproveite enquanto esta condição especial ainda está disponível.
            </p>
          </div>
        </div>
      </section>

      {/* Guarantee */}
      <section className="section">
        <div className="container">
          <div className="guarantee-box">
            <h1 style={{fontSize:'4rem', marginBottom:'1rem'}}>🛡️</h1>
            <h2>7 DIAS DE GARANTIA TOTAL</h2>
            <h3 style={{marginBottom:'1rem'}}>Experimente a UltraLiss Pro® com confiança.</h3>
            <p>Você tem 7 dias para testar a UltraLiss Pro® e sentir a diferença no seu cabelo. Se não gostar do resultado, devolvemos 100% do seu dinheiro dentro do prazo de garantia.</p>
            <div style={{display:'flex', gap:'1rem', justifyContent:'center', flexWrap:'wrap', marginTop:'2rem'}}>
              <span style={{background:'var(--primary-light)', padding:'0.5rem 1rem', borderRadius:'50px', fontWeight:'600'}}>5 níveis de temperatura</span>
              <span style={{background:'var(--primary-light)', padding:'0.5rem 1rem', borderRadius:'50px', fontWeight:'600'}}>Aquecimento rápido</span>
              <span style={{background:'var(--primary-light)', padding:'0.5rem 1rem', borderRadius:'50px', fontWeight:'600'}}>Não danifica os fios</span>
              <span style={{background:'var(--primary-light)', padding:'0.5rem 1rem', borderRadius:'50px', fontWeight:'600'}}>Todos os cabelos</span>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="section bg-gray" id="faq">
        <div className="container">
          <div className="text-center">
            <h2>Perguntas Frequentes (FAQ)</h2>
            <p style={{ maxWidth: '600px', margin: '0 auto 3rem' }}>Tire suas dúvidas sobre a UltraLiss Pro®</p>
          </div>
          
          <div className="faq-list">
            {faqs.map((faq, index) => (
              <div key={index} className={`faq-item ${activeFaq === index ? 'active' : ''}`}>
                <div className="faq-question" onClick={() => toggleFaq(index)}>
                  {faq.question}
                  <span style={{ fontSize: '1.25rem', transition: 'transform 0.3s ease', transform: activeFaq === index ? 'rotate(45deg)' : 'rotate(0)' }}>+</span>
                </div>
                <div className="faq-answer">
                  {faq.answer}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <h2 style={{ color: 'var(--white)', marginBottom: '1rem', letterSpacing: '2px' }}>Ultra Beauty Brasil</h2>
          <p style={{ color: '#a0aec0', marginBottom: '2rem' }}>Beleza, praticidade e confiança para sua rotina.</p>
          
          <div style={{borderTop: '1px solid #2d3748', borderBottom: '1px solid #2d3748', padding: '2rem 0', margin: '2rem 0'}}>
            <h3 style={{color: 'var(--white)', marginBottom: '1.5rem'}}>Por que comprar conosco?</h3>
            <div className="footer-links">
              <span>🔒 Compra Segura</span>
              <span>🚚 Frete para Todo Brasil</span>
              <span>🛡️ Pagamento Protegido</span>
              <span>🎧 Suporte ao Cliente</span>
            </div>
          </div>

          <div style={{textAlign:'left', maxWidth:'400px', margin:'0 auto 3rem'}}>
            <h3 style={{color:'var(--white)', marginBottom:'1rem'}}>UltraLiss Pro®</h3>
            <p style={{marginBottom:'0.5rem'}}>✨ Cabelos mais alinhados em poucos minutos</p>
            <p style={{marginBottom:'0.5rem'}}>🔥 5 níveis de temperatura inteligentes</p>
            <p style={{marginBottom:'0.5rem'}}>💖 Menos frizz e acabamento mais sedoso</p>
            <p style={{marginBottom:'0.5rem'}}>🚚 Frete grátis para todo o Brasil</p>
            <p className="font-bold text-success" style={{marginTop:'1rem'}}>Garanta sua UltraLiss Pro® com desconto especial hoje.</p>
          </div>
          
          <p style={{ color: '#718096', fontSize: '0.9rem' }}>© 2026 Glamora. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
